from flask_sqlalchemy import SQLAlchemy
db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    email = db.Column(db.String(120), unique=True)
    password = db.Column(db.String(200))
    role = db.Column(db.String(10))  # Author, Reviewer, Admin
    profile_photo = db.Column(db.String(200))  # filename

class Paper(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200))
    abstract = db.Column(db.Text)
    authors = db.Column(db.Text)
    corresponding_author = db.Column(db.String(100))
    topics = db.Column(db.String(200))
    agreement = db.Column(db.Boolean)
    file = db.Column(db.String(200))
    author_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    final_decision = db.Column(db.String(20)) # Accept/Reject/Revise
    orcid = db.Column(db.String(30))
    website = db.Column(db.String(200))
    biography = db.Column(db.Text)

class Review(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    paper_id = db.Column(db.Integer, db.ForeignKey('paper.id'))
    reviewer_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    score1 = db.Column(db.Integer)
    score2 = db.Column(db.Integer)
    comments = db.Column(db.Text)
    private_notes = db.Column(db.Text)  # Only visible to chair/admin
    conflict_of_interest = db.Column(db.String(10))
    remarks = db.Column(db.Text)  # For edit/add remarks

class Conference(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200))
    submission_deadline = db.Column(db.String(50))
    review_deadline = db.Column(db.String(50))

class Notification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    recipient_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    message = db.Column(db.String(255))
    url = db.Column(db.String(255))
    is_read = db.Column(db.Boolean, default=False)
    timestamp = db.Column(db.DateTime, server_default=db.func.now())