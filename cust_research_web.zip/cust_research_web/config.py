import os

class Config:
    SECRET_KEY = 'your_secret_key'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///cust_research_web.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'static', 'uploads')
    PROFILE_PHOTO_FOLDER = os.path.join(os.path.dirname(__file__), 'static', 'profile_photos')
    ALLOWED_EXTENSIONS = {'pdf', 'docx'}