from flask import Flask, render_template, redirect, url_for, request, session, flash, send_from_directory, g
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from models import db, User, Paper, Review, Conference, Notification
import os
import re

app = Flask(__name__)
app.config.from_object('config.Config')
db.init_app(app)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

def create_notification(recipient_id, message, url):
    notif = Notification(recipient_id=recipient_id, message=message, url=url, is_read=False)
    db.session.add(notif)
    db.session.commit()

@app.before_request
def load_user():
    g.user = None
    g.notifications = []
    g.unread_notifications = 0
    if 'user_id' in session:
        g.user = User.query.get(session['user_id'])
        if g.user:
            g.notifications = Notification.query.filter_by(recipient_id=g.user.id).order_by(Notification.timestamp.desc()).limit(15).all()
            g.unread_notifications = Notification.query.filter_by(recipient_id=g.user.id, is_read=False).count()

@app.route('/read_notification/<int:notif_id>')
def read_notification(notif_id):
    notif = Notification.query.get_or_404(notif_id)
    notif.is_read = True
    db.session.commit()
    return '', 204

@app.route('/')
def home():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email).first()
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            session['role'] = user.role
            return redirect(url_for(f'dashboard_{user.role.lower()}'))
        else:
            flash('Invalid credentials. Password is case sensitive.')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password_raw = request.form['password']
        role = request.form['role']
        profile_photo = None

        # Password validation
        if len(password_raw) < 8 or \
           not re.search(r'[A-Z]', password_raw) or \
           not re.search(r'[a-z]', password_raw) or \
           not re.search(r'[0-9]', password_raw) or \
           not re.search(r'[^\w]', password_raw):
            flash('Password must be at least 8 characters, include uppercase, lowercase, digit and special symbol.')
            return render_template('register.html')

        password = generate_password_hash(password_raw)
        if 'profile_photo' in request.files and request.files['profile_photo']:
            file = request.files['profile_photo']
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['PROFILE_PHOTO_FOLDER'], filename))
            profile_photo = filename
        if User.query.filter_by(email=email).first():
            flash('Email already exists')
            return render_template('register.html')
        user = User(name=name, email=email, password=password, role=role, profile_photo=profile_photo)
        db.session.add(user)
        db.session.commit()
        flash('Registration successful. Please login.')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/dashboard/author')
def dashboard_author():
    user = User.query.get(session.get('user_id'))
    if user and user.role == 'Author':
        papers = Paper.query.filter_by(author_id=user.id).all()
        total_papers = len(papers)
        accepted_papers = sum(1 for p in papers if p.final_decision == 'Accept')
        rejected_papers = sum(1 for p in papers if p.final_decision == 'Reject')
        not_reviewed = sum(1 for p in papers if not p.final_decision)
        stats = {
            "total_papers": total_papers,
            "accepted_papers": accepted_papers,
            "rejected_papers": rejected_papers,
            "not_reviewed": not_reviewed
        }
        return render_template('dashboard_author.html', user=user, papers=papers, active='dashboard_author', stats=stats)
    return redirect(url_for('login'))

@app.route('/dashboard/reviewer')
def dashboard_reviewer():
    user = User.query.get(session.get('user_id'))
    if user and user.role == 'Reviewer':
        reviews = Review.query.filter_by(reviewer_id=user.id).all()
        assigned_papers = []
        for review in reviews:
            paper = Paper.query.get(review.paper_id)
            if paper:
                assigned_papers.append({'paper': paper, 'review': review})
        total_assigned = len(assigned_papers)
        total_reviewed = sum(1 for a in assigned_papers if a['review'].remarks)
        total_pending = total_assigned - total_reviewed
        review_stats = {
            'assigned': total_assigned,
            'reviewed': total_reviewed,
            'pending': total_pending,
        }
        return render_template(
            'dashboard_reviewer.html',
            user=user,
            assigned_papers=assigned_papers,
            active='dashboard_reviewer',
            review_stats=review_stats
        )
    return redirect(url_for('login'))

@app.route('/edit_remark/<int:review_id>', methods=['GET', 'POST'])
def edit_remark(review_id):
    review = Review.query.get_or_404(review_id)
    if request.method == 'POST':
        review.remarks = request.form['remarks']
        db.session.commit()
        return redirect(url_for('dashboard_reviewer'))
    return render_template('edit_remark.html', review=review)

@app.route('/dashboard/admin')
def dashboard_admin():
    user = User.query.get(session.get('user_id'))
    if user and user.role == 'Admin':
        conferences = Conference.query.all()
        papers = Paper.query.all()
        total_papers = len(papers)
        accepted_papers = sum(1 for p in papers if p.final_decision == 'Accept')
        rejected_papers = sum(1 for p in papers if p.final_decision == 'Reject')
        other_papers = total_papers - accepted_papers - rejected_papers
        reviewer_count = User.query.filter_by(role='Reviewer').count()
        stats = {
            "total_papers": total_papers,
            "accepted_papers": accepted_papers,
            "rejected_papers": rejected_papers,
            "other_papers": other_papers,
            "reviewer_count": reviewer_count
        }
        return render_template('dashboard_admin.html', user=user, conferences=conferences, papers=papers, active='dashboard_admin', stats=stats)
    return redirect(url_for('login'))

@app.route('/profile')
def profile():
    user = User.query.get(session.get('user_id'))
    if not user:
        return redirect(url_for('login'))
    return render_template('profile.html', user=user, active='profile')

@app.route('/edit_profile', methods=['GET', 'POST'])
def edit_profile():
    user = User.query.get(session.get('user_id'))
    if not user:
        return redirect(url_for('login'))
    if request.method == 'POST':
        user.name = request.form['name']
        if 'profile_photo' in request.files and request.files['profile_photo']:
            file = request.files['profile_photo']
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['PROFILE_PHOTO_FOLDER'], filename))
            user.profile_photo = filename
        db.session.commit()
        flash('Profile updated successfully.')
        return redirect(url_for('profile'))
    return render_template('edit_profile.html', user=user, active='edit_profile')

@app.route('/submit_paper', methods=['GET', 'POST'])
def submit_paper():
    user = User.query.get(session.get('user_id'))
    if user and user.role == 'Author':
        if request.method == 'POST':
            title = request.form['title']
            abstract = request.form['abstract']
            authors = request.form['authors']
            corresponding_author = request.form['corresponding_author']
            topics = request.form['topics']
            agreement = 'agreement' in request.form
            orcid = request.form.get('orcid')
            website = request.form.get('website')
            biography = request.form.get('biography')
            filename = None
            file = request.files.get('file')
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            elif file and file.filename != '':
                flash('Invalid file type. Only PDF and DOCX allowed.')
                return render_template('submit_paper.html', user=user, active='submit_paper')
            paper = Paper(
                title=title,
                abstract=abstract,
                authors=authors,
                corresponding_author=corresponding_author,
                topics=topics,
                agreement=agreement,
                file=filename,
                author_id=user.id,
                orcid=orcid,
                website=website,
                biography=biography
            )
            db.session.add(paper)
            db.session.commit()
            flash('Paper submitted successfully')
            chair = User.query.filter_by(role='Admin').first()
            if chair:
                create_notification(chair.id, f"New paper submitted by Author {user.name}.", url_for('dashboard_admin'))
            return redirect(url_for('dashboard_author'))
        return render_template('submit_paper.html', user=user, active='submit_paper')
    return redirect(url_for('login'))

@app.route('/edit_paper/<int:paper_id>', methods=['GET', 'POST'])
def edit_paper(paper_id):
    paper = Paper.query.get_or_404(paper_id)
    user = User.query.get(session.get('user_id'))
    if user and user.role == 'Author' and paper.author_id == user.id:
        if request.method == 'POST':
            paper.title = request.form['title']
            paper.abstract = request.form['abstract']
            paper.authors = request.form['authors']
            paper.corresponding_author = request.form['corresponding_author']
            paper.topics = request.form['topics']
            paper.agreement = 'agreement' in request.form
            paper.orcid = request.form.get('orcid')
            paper.website = request.form.get('website')
            paper.biography = request.form.get('biography')
            file = request.files.get('file')
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                paper.file = filename
            elif file and file.filename != '':
                flash('Invalid file type. Only PDF and DOCX allowed.')
                return render_template('edit_paper.html', user=user, paper=paper, active='edit_paper')
            db.session.commit()
            flash('Paper updated successfully')
            return redirect(url_for('dashboard_author'))
        return render_template('edit_paper.html', user=user, paper=paper, active='edit_paper')
    return redirect(url_for('login'))

@app.route('/delete_paper/<int:paper_id>', methods=['POST'])
def delete_paper(paper_id):
    paper = Paper.query.get_or_404(paper_id)
    user = User.query.get(session.get('user_id'))
    if user and user.role == 'Author' and paper.author_id == user.id:
        paper_title = paper.title
        db.session.delete(paper)
        db.session.commit()
        flash('Paper deleted successfully')
        chair = User.query.filter_by(role='Admin').first()
        if chair:
            create_notification(chair.id, f"Paper '{paper_title}' was deleted by Author {user.name}.", url_for('dashboard_admin'))
    return redirect(url_for('dashboard_author'))

@app.route('/view_paper/<int:paper_id>')
def view_paper(paper_id):
    paper = Paper.query.get_or_404(paper_id)
    user = User.query.get(session.get('user_id'))
    if user:
        return render_template('view_paper.html', user=user, paper=paper, active='view_paper')
    return redirect(url_for('login'))

@app.route('/view_remarks/<int:paper_id>')
def view_remarks(paper_id):
    paper = Paper.query.get_or_404(paper_id)
    reviews = Review.query.filter_by(paper_id=paper.id).all()
    user = User.query.get(session.get('user_id'))
    if not user:
        return redirect(url_for('login'))
    if user.role == 'Author' and paper.author_id == user.id:
        return render_template('view_remarks.html', user=user, reviews=reviews, paper=paper, active='view_remarks')
    elif user.role == 'Admin':
        return render_template('view_remarks.html', user=user, reviews=reviews, paper=paper, active='view_remarks')
    else:
        flash('Access denied.')
        return redirect(url_for('home'))

@app.route('/admin_private_notes/<int:paper_id>')
def admin_private_notes(paper_id):
    paper = Paper.query.get_or_404(paper_id)
    reviews = Review.query.filter_by(paper_id=paper.id).all()
    user = User.query.get(session.get('user_id'))
    if user and user.role == 'Admin':
        return render_template('admin_private_notes.html', user=user, reviews=reviews, paper=paper)
    return redirect(url_for('login'))

@app.route('/review_paper/<int:review_id>', methods=['GET', 'POST'])
def review_paper(review_id):
    review = Review.query.get_or_404(review_id)
    paper = Paper.query.get_or_404(review.paper_id)
    user = User.query.get(session.get('user_id'))
    if user and user.role == 'Reviewer' and review.reviewer_id == user.id:
        if request.method == 'POST':
            review.score1 = int(request.form['score1'])
            review.score2 = int(request.form['score2'])
            review.comments = request.form['comments']
            review.private_notes = request.form.get('private_notes')
            review.conflict_of_interest = request.form.get('conflict_of_interest')
            db.session.commit()
            flash('Review submitted/updated')
            if review.comments:
                author_id = paper.author_id
                reviewer = User.query.get(review.reviewer_id)
                create_notification(author_id, f"Reviewer {reviewer.name} added remarks on your paper.", url_for('view_remarks', paper_id=paper.id))
            if review.private_notes:
                chair = User.query.filter_by(role='Admin').first()
                reviewer = User.query.get(review.reviewer_id)
                create_notification(chair.id, f"Reviewer {reviewer.name} added a private note for you on Paper #{review.paper_id}.", url_for('admin_private_notes', paper_id=review.paper_id))
            return redirect(url_for('dashboard_reviewer'))
        return render_template('review_paper.html', user=user, review=review, paper=paper, active='review_paper')
    return redirect(url_for('login'))

@app.route('/conference_manager', methods=['GET', 'POST'])
def conference_manager():
    user = User.query.get(session.get('user_id'))
    if user and user.role == 'Admin':
        if request.method == 'POST':
            name = request.form['name']
            submission_deadline = request.form['submission_deadline']
            review_deadline = request.form['review_deadline']
            conference = Conference(name=name, submission_deadline=submission_deadline, review_deadline=review_deadline)
            db.session.add(conference)
            db.session.commit()
            flash('Conference created')
        conferences = Conference.query.all()
        return render_template('conference_manager.html', user=user, conferences=conferences, active='conference_manager')
    return redirect(url_for('login'))

@app.route('/assign_reviewers', methods=['GET', 'POST'])
def assign_reviewers():
    user = User.query.get(session.get('user_id'))
    if user and user.role == 'Admin':
        papers = Paper.query.all()
        reviewers = User.query.filter_by(role='Reviewer').all()
        if request.method == 'POST':
            paper_id = int(request.form['paper_id'])
            reviewer_id = int(request.form['reviewer_id'])
            if not Review.query.filter_by(paper_id=paper_id, reviewer_id=reviewer_id).first():
                review = Review(paper_id=paper_id, reviewer_id=reviewer_id)
                db.session.add(review)
                db.session.commit()
                flash('Reviewer assigned')
                create_notification(reviewer_id, f"You have been assigned Paper #{paper_id} for review.", url_for('review_paper', review_id=review.id))
        return render_template('assign_reviewers.html', user=user, papers=papers, reviewers=reviewers, active='assign_reviewers')
    return redirect(url_for('login'))

@app.route('/decision_panel', methods=['GET', 'POST'])
def decision_panel():
    user = User.query.get(session.get('user_id'))
    if user and user.role == 'Admin':
        papers = Paper.query.all()
        if request.method == 'POST':
            paper_id = int(request.form['paper_id'])
            decision = request.form['decision']
            paper = Paper.query.get(paper_id)
            paper.final_decision = decision
            db.session.commit()
            flash('Decision updated')
            create_notification(paper.author_id, f"Final decision on your paper: {decision}.", url_for('view_paper', paper_id=paper.id))
        return render_template('decision_panel.html', user=user, papers=papers, active='decision_panel')
    return redirect(url_for('login'))

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/profile_photos/<filename>')
def profile_photo(filename):
    return send_from_directory(app.config['PROFILE_PHOTO_FOLDER'], filename)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)